# Tab Activity — Chrome Web Store submission package

Everything below maps to a field in the Developer Dashboard. Copy-paste in order.

---

## Store listing

**Name**
Tab Activity

**Summary** (max 132 characters — this one is 124)
See where your attention actually went. A beautiful, private time dial for your browsing. All data stays on your device.

**Category:** Workflow & Planning (alternative: Tools)

**Language:** English

**Description**

```
A tab being open is not the same as you being there.

Most time trackers count how long a tab existed — so twenty pinned tabs all
report eight hours, and the numbers mean nothing. Tab Activity measures
something stricter: a site only earns time while its tab is focused, its
window is focused, and you are actually active at the keyboard. Step away
and the clock pauses. Watch a film fullscreen and it doesn't.

What's left is an honest record of your attention — drawn beautifully
enough that you'll actually look at it.

THE ATTENTION DIAL
Your day on a 24-hour face: midnight at the top, each site on its own ring,
each focused session a luminous arc. Hover for page titles and exact times.
A hand marks now; the centre keeps your running total. Below it, a film-strip
timeline lays the same day out flat, frame by frame.

WEEK · MONTH · YEAR
A 7×24 heatmap shows when in the week your attention burns brightest, with
peak-hour and busiest-day stats. Month and year views stack each day into
colored bars until your history reads like a texture.

CATEGORIES
Tag domains as Work, Learning, Entertainment — whatever fits your life —
and flip any view to read by intent instead of by site.

LIMITS THAT RESPECT YOU
Set a daily allowance per site, or one budget for everything. Cross it and
you get a single quiet notification — once, not a nag. Tab Activity warns;
it never blocks. The choice stays yours.

YOUR DATA, YOUR CONTROLS
Exclude sites from tracking entirely. Hide sites from view. Purge a single
domain's history. Export everything as JSON or CSV. Wipe it all. An optional
toolbar badge shows today's total. Four themes: Noir, Dawn, Sea, Forest.

PRIVATE BY ARCHITECTURE
Tab Activity makes no network requests — ever. No server, no account, no
sync, no analytics, no third-party code. Only site domains are kept long
term (youtube.com, never the full URL). Page titles are held at most 7 days,
then discarded. Incognito is never tracked. Everything lives in your
browser's local database, and deleting it deletes it.

A tracker you don't have to trust — because it can't tell anyone.
```

**Privacy policy URL**
https://<your-github-username>.github.io/tab-activity/privacy.html

**Homepage URL** (optional)
https://<your-github-username>.github.io/tab-activity/

---

## Privacy practices tab

**Single purpose description**

```
Tab Activity measures the time the user actively spends on websites (which
tab is focused, for how long) and visualizes it locally as daily, weekly,
monthly, and yearly summaries. All data is stored on the user's device;
the extension makes no network requests.
```

**Permission justifications**

- **tabs** — Required to detect which tab is currently focused and to read
  that tab's domain and title, which is the extension's core measurement.
  The extension does not read or modify page content and requests no host
  permissions.
- **idle** — Required to pause time tracking when the user is away from the
  keyboard, so that idle time is not counted as attention.
- **alarms** — Required for a once-per-minute heartbeat (to correctly
  truncate sessions after system sleep) and a nightly local aggregation of
  raw sessions into daily totals.
- **storage** — Required to persist user settings and the in-progress
  session locally on the device.
- **notifications** — Used only if the user sets optional daily time limits:
  shows at most one notification per limit per day when a limit is crossed.

**Remote code:** No, I am not using remote code.
(All code ships in the package. Google Fonts stylesheets are loaded for the
dashboard/options pages' typography only; no executable code is fetched.
If the reviewer flags this, self-host the two font files — see notes below.)

**Data usage disclosures** — check NONE of the collection boxes.
The form's categories (personally identifiable information, health, financial,
authentication, personal communications, location, web history, user activity,
website content): Tab Activity stores domain-level browsing time **locally
on the device only** and transmits nothing. The dashboard's certification
questions about selling/transferring data: answer that no data is sold or
transferred; nothing leaves the device.

> Note: some reviewers treat locally-stored domain history as "web history"
> data that must be declared even without transmission. If asked to revise,
> declare "web history" as collected, mark it as NOT sold, NOT transferred,
> NOT used for unrelated purposes — and keep the policy URL pointing at
> privacy.html, which already describes exactly this.

---

## Assets checklist

- **Icon 128×128** — icon128.png (in the package) ✓
- **Small promo tile 440×280** — promo-440x280.png (provided alongside this file) ✓
- **Screenshots, 1280×800 (1–5)** — capture from the real extension:
  1. Today dial with a full day (hover a tooltip before capturing)
  2. Week heatmap
  3. Month stacked bars
  4. Options page (domains + limits visible)
  5. Dawn theme for contrast
- **Marquee 1400×560** — optional; skip for first submission.

## Pre-submission notes

- The upload zip must have manifest.json at the ROOT (tab-activity-webstore-
  v0.3.0.zip is packaged this way; the -local zip nests an extension/ folder
  for Load unpacked and will be REJECTED by the dashboard).
- Fill in the two <your-github-username> URLs before submitting.
- GitHub Pages: push the site/ folder contents to the repo, Settings →
  Pages → deploy from branch. privacy.html must be live BEFORE submission;
  reviewers follow the link.
- Consider self-hosting the Marcellus + IBM Plex Mono woff2 files in a
  fonts/ folder to remove the only external requests the pages make.
  Functionally nothing depends on them (system fallbacks are declared).
